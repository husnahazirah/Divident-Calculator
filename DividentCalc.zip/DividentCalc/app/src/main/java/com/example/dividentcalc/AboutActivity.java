package com.example.dividentcalc;

import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {

    Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        // Link the back button
        backButton = findViewById(R.id.backButton);

        // Set click listener to return to MainActivity
        backButton.setOnClickListener(v -> finish());
    }
}