package com.example.dividentcalc;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText investedAmount, dividendRate, monthsInvested;
    Button calculateButton, aboutButton;
    TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Link UI components
        investedAmount = findViewById(R.id.investedAmount);
        dividendRate = findViewById(R.id.dividendRate);
        monthsInvested = findViewById(R.id.monthsInvested);
        calculateButton = findViewById(R.id.calculateButton);
        aboutButton = findViewById(R.id.aboutButton);
        resultText = findViewById(R.id.resultText);

        // Calculate Button Logic
        calculateButton.setOnClickListener(v -> {
            try {
                double fund = Double.parseDouble(investedAmount.getText().toString());
                double rate = Double.parseDouble(dividendRate.getText().toString());
                int months = Integer.parseInt(monthsInvested.getText().toString());

                if (months > 12 || months < 1) {
                    Toast.makeText(this, "Please enter months between 1 and 12", Toast.LENGTH_SHORT).show();
                    return;
                }

                double monthlyDividend = (rate / 100) / 12 * fund;
                double totalDividend = monthlyDividend * months;

                resultText.setText(String.format("Total Dividend: %.2f", totalDividend));

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show();
            }
        });

        // About Button Navigation
        aboutButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, com.example.dividentcalc.AboutActivity.class);
            startActivity(intent);
        });
    }
}